import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text
} from "react-native";
import MaterialIconTextButtonsFooter from "../components/MaterialIconTextButtonsFooter";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import { Center } from "@builderx/utils";
import EntypoIcon from "react-native-vector-icons/Entypo";

function HomeScreenStud(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <MaterialIconTextButtonsFooter
        style={styles.materialIconTextButtonsFooter1}
      ></MaterialIconTextButtonsFooter>
      <View style={styles.contain1}>
        <View style={styles.centerContainer1}>
          <View style={styles.leftGrp1}>
            <View style={styles.grp1}>
              <View style={styles.grp2}></View>
              <TouchableOpacity style={styles.grp3}>
                <View style={styles.rect1}>
                  <MaterialCommunityIconsIcon
                    name="qrcode-scan"
                    style={styles.icon1}
                  ></MaterialCommunityIconsIcon>
                  <Text style={styles.scanQrCode1}>Scan QR Code</Text>
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.grp4}>
              <View style={styles.grp5}></View>
              <Center>
                <View style={styles.rect4}></View>
              </Center>
            </View>
          </View>
          <View style={styles.rightGrp1}>
            <View style={styles.grp7}>
              <View style={styles.grp8}></View>
              <Center>
                <TouchableOpacity style={styles.grp9}>
                  <View style={styles.rect3}>
                    <EntypoIcon name="list" style={styles.icon3}></EntypoIcon>
                    <Text style={styles.viewList2}>View List</Text>
                  </View>
                </TouchableOpacity>
              </Center>
            </View>
            <View style={styles.grp10}>
              <View style={styles.grp11}></View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  materialIconTextButtonsFooter1: {
    height: 56,
    backgroundColor: "rgba(255,255,255,1)",
    marginTop: 684
  },
  contain1: {
    height: 381,
    flexDirection: "row",
    justifyContent: "center",
    marginTop: -680
  },
  centerContainer1: {
    width: 334,
    height: 351,
    flexDirection: "row",
    alignSelf: "center"
  },
  leftGrp1: {
    flex: 0.5,
    backgroundColor: "rgba(247, 247, 247,1)"
  },
  grp1: {
    flex: 0.5,
    backgroundColor: "rgba(255,255,255,1)"
  },
  grp2: {
    flex: 1,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    overflow: "hidden",
    backgroundColor: "rgba(230,230,230,1)"
  },
  grp3: {
    top: 13,
    left: 8,
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect1: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid"
  },
  icon1: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    marginTop: 42,
    marginLeft: 45
  },
  scanQrCode1: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 16,
    marginLeft: 48
  },
  grp4: {
    flex: 0.5
  },
  grp5: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  rect4: {
    width: 150,
    height: 150,
    position: "absolute"
  },
  rightGrp1: {
    flex: 0.5,
    backgroundColor: "rgba(210, 210, 210,1)"
  },
  grp7: {
    flex: 0.5,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  grp8: {
    flex: 1,
    backgroundColor: "rgba(230,230,230,1)"
  },
  grp9: {
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect3: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid"
  },
  icon3: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    marginTop: 42,
    marginLeft: 45
  },
  viewList2: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 16,
    marginLeft: 77
  },
  grp10: {
    flex: 0.5
  },
  grp11: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  }
});

export default HomeScreenStud;
