import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";
import IoniconsIcon from "react-native-vector-icons/Ionicons";

function Warning(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group1}>
        <View style={styles.rect1}>
          <View style={styles.icon1Row}>
            <IoniconsIcon
              name="ios-arrow-back"
              style={styles.icon1}
            ></IoniconsIcon>
            <Text style={styles.text}>WARNING</Text>
          </View>
        </View>
      </View>
      <View style={styles.group2}>
        <View style={styles.warning_shadding}>
          <View style={styles.icon2Row}>
            <IoniconsIcon name="ios-alert" style={styles.icon2}></IoniconsIcon>
            <Text style={styles.alert}>Alert!</Text>
          </View>
          <View style={styles.group3}>
            <View style={styles.rect2}>
              <Text style={styles.mesg}>
                Write a message here...{"\n"}e.g., You have received this
                message because {"\n"}you were trying to do some shit with the
                app.
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230,230,230,1)"
  },
  group1: {
    height: 60
  },
  rect1: {
    height: 60,
    backgroundColor: "rgba(8,8,8,1)",
    flexDirection: "row"
  },
  icon1: {
    color: "rgba(255,255,255,1)",
    fontSize: 32,
    height: 35,
    width: 12
  },
  text: {
    fontFamily: "roboto-700",
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 19,
    marginTop: 7
  },
  icon1Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 227,
    marginLeft: 20,
    marginTop: 12
  },
  group2: {
    height: 349,
    marginTop: 65
  },
  warning_shadding: {
    height: 349,
    backgroundColor: "rgba(255,255,255,1)"
  },
  icon2: {
    color: "rgba(238,11,11,1)",
    fontSize: 49,
    height: 53,
    width: 40
  },
  alert: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 16,
    marginLeft: 12,
    marginTop: 17
  },
  icon2Row: {
    height: 53,
    flexDirection: "row",
    marginTop: 17,
    marginLeft: 134,
    marginRight: 134
  },
  group3: {
    width: 314,
    height: 190,
    marginTop: 32,
    marginLeft: 23
  },
  rect2: {
    width: 314,
    height: 190,
    backgroundColor: "rgba(255,255,255,1)"
  },
  mesg: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 14,
    textAlign: "left",
    flex: 1
  }
});

export default Warning;
