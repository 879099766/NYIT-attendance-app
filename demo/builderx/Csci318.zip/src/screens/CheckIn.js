import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  Text,
  TextInput,
  TouchableOpacity
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

function CheckIn(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group1}>
        <View style={styles.rect1}>
          <View style={styles.icon1Row}>
            <Icon name="ios-arrow-back" style={styles.icon1}></Icon>
            <Text style={styles.csci318CheckIn}>CSCI 318 - Check In</Text>
          </View>
        </View>
      </View>
      <View style={styles.group2}>
        <View style={styles.background1}>
          <View style={styles.inputShadding}>
            <TextInput
              placeholder="   Student ID"
              clearButtonMode="while-editing"
              autoCapitalize="sentences"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              keyboardType="number-pad"
              maxLength={7}
              style={styles.input}
            ></TextInput>
          </View>
          <TouchableOpacity style={styles.btnSubmit1}>
            <Text style={styles.btnTxtSubmit1}>Submit</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230,230,230,1)"
  },
  group1: {
    height: 60
  },
  rect1: {
    height: 60,
    backgroundColor: "rgba(8,8,8,1)",
    flexDirection: "row"
  },
  icon1: {
    color: "rgba(255,255,255,1)",
    fontSize: 32,
    height: 35,
    width: 12
  },
  csci318CheckIn: {
    fontFamily: "roboto-700",
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 19,
    marginTop: 7
  },
  icon1Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 147,
    marginLeft: 20,
    marginTop: 12
  },
  group2: {
    height: 171,
    marginTop: 25
  },
  background1: {
    height: 170,
    backgroundColor: "rgba(255,255,255,1)"
  },
  inputShadding: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 36,
    marginLeft: 15
  },
  input: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  btnSubmit1: {
    width: 328,
    height: 33,
    backgroundColor: "rgba(7,161,80,1)",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(252,252,252,1)",
    overflow: "hidden",
    marginTop: 26,
    marginLeft: 16
  },
  btnTxtSubmit1: {
    fontFamily: "roboto-regular",
    color: "rgba(255,252,252,1)",
    marginTop: 9,
    marginLeft: 142
  }
});

export default CheckIn;
