import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, ScrollView } from "react-native";
import IoniconsIcon from "react-native-vector-icons/Ionicons";
import FeatherIcon from "react-native-vector-icons/Feather";

function AttendanceList(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group1}>
        <View style={styles.rect1}>
          <View style={styles.icon1Row}>
            <IoniconsIcon
              name="ios-arrow-back"
              style={styles.icon1}
            ></IoniconsIcon>
            <Text style={styles.text1}>Attendance List</Text>
          </View>
        </View>
      </View>
      <View style={styles.group2}>
        <View style={styles.scrollArea}>
          <ScrollView
            horizontal={false}
            contentContainerStyle={styles.scrollArea_contentContainerStyle}
          >
            <View style={styles.group3}>
              <View style={styles.list_item_shadding}>
                <View style={styles.list_item_profileIMGRow}>
                  <FeatherIcon
                    name="user"
                    style={styles.list_item_profileIMG}
                  ></FeatherIcon>
                  <View style={styles.list_item_namesColumn}>
                    <Text style={styles.list_item_names}>
                      Last Name, First Name
                    </Text>
                    <Text style={styles.list_item_stuID}>1234567</Text>
                  </View>
                  <Text style={styles.list_item_time}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
            <View style={styles.group4}>
              <View style={styles.rect2}>
                <View style={styles.icon2Row}>
                  <FeatherIcon name="user" style={styles.icon2}></FeatherIcon>
                  <View style={styles.text2Column}>
                    <Text style={styles.text2}>Last Name, First Name</Text>
                    <Text style={styles.text3}>1234567</Text>
                  </View>
                  <Text style={styles.text4}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
            <View style={styles.group5}>
              <View style={styles.rect3}>
                <View style={styles.icon3Row}>
                  <FeatherIcon name="user" style={styles.icon3}></FeatherIcon>
                  <View style={styles.text5Column}>
                    <Text style={styles.text5}>Last Name, First Name</Text>
                    <Text style={styles.text6}>1234567</Text>
                  </View>
                  <Text style={styles.text7}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
            <View style={styles.group6}>
              <View style={styles.rect4}>
                <View style={styles.icon4Row}>
                  <FeatherIcon name="user" style={styles.icon4}></FeatherIcon>
                  <View style={styles.text8Column}>
                    <Text style={styles.text8}>Last Name, First Name</Text>
                    <Text style={styles.text9}>1234567</Text>
                  </View>
                  <Text style={styles.text10}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
            <View style={styles.group7}>
              <View style={styles.rect5}>
                <View style={styles.icon5Row}>
                  <FeatherIcon name="user" style={styles.icon5}></FeatherIcon>
                  <View style={styles.text11Column}>
                    <Text style={styles.text11}>Last Name, First Name</Text>
                    <Text style={styles.text12}>1234567</Text>
                  </View>
                  <Text style={styles.text13}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
            <View style={styles.group8}>
              <View style={styles.rect6}>
                <View style={styles.icon6Row}>
                  <FeatherIcon name="user" style={styles.icon6}></FeatherIcon>
                  <View style={styles.text14Column}>
                    <Text style={styles.text14}>Last Name, First Name</Text>
                    <Text style={styles.text15}>1234567</Text>
                  </View>
                  <Text style={styles.text16}>12:30 01/30/3030</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  group1: {
    width: 360,
    height: 60
  },
  rect1: {
    height: 60,
    backgroundColor: "rgba(8,8,8,1)",
    flexDirection: "row"
  },
  icon1: {
    color: "rgba(255,255,255,1)",
    fontSize: 32,
    height: 35,
    width: 12
  },
  text1: {
    fontFamily: "roboto-700",
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 19,
    marginTop: 7
  },
  icon1Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 181,
    marginLeft: 20,
    marginTop: 12
  },
  group2: {
    height: 680
  },
  scrollArea: {
    height: 680
  },
  scrollArea_contentContainerStyle: {
    height: 680
  },
  group3: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000",
    borderStyle: "solid"
  },
  list_item_shadding: {
    height: 80
  },
  list_item_profileIMG: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  list_item_names: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  list_item_stuID: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  list_item_namesColumn: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  list_item_time: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  list_item_profileIMGRow: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  },
  group4: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000"
  },
  rect2: {
    height: 80
  },
  icon2: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  text2: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  text3: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  text2Column: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  text4: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  icon2Row: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  },
  group5: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000"
  },
  rect3: {
    height: 80
  },
  icon3: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  text5: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  text6: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  text5Column: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  text7: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  icon3Row: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  },
  group6: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000"
  },
  rect4: {
    height: 80
  },
  icon4: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  text8: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  text9: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  text8Column: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  text10: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  icon4Row: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  },
  group7: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000"
  },
  rect5: {
    height: 80
  },
  icon5: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  text11: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  text12: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  text11Column: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  text13: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  icon5Row: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  },
  group8: {
    height: 80,
    borderWidth: 1,
    borderColor: "#000000"
  },
  rect6: {
    height: 80
  },
  icon6: {
    color: "rgba(83,83,83,1)",
    fontSize: 40,
    width: 40,
    height: 41,
    marginTop: 4
  },
  text14: {
    fontFamily: "roboto-700",
    color: "#121212",
    fontSize: 15
  },
  text15: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    marginTop: 3
  },
  text14Column: {
    width: 154,
    marginLeft: 18,
    marginBottom: 19
  },
  text16: {
    fontFamily: "roboto-regular",
    color: "rgba(133,133,133,1)",
    fontSize: 13,
    textAlign: "right",
    marginLeft: 9,
    marginTop: 40
  },
  icon6Row: {
    height: 55,
    flexDirection: "row",
    marginTop: 16,
    marginLeft: 20,
    marginRight: 9
  }
});

export default AttendanceList;
