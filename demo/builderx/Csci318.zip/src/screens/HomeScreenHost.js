import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text
} from "react-native";
import MaterialIconTextButtonsFooter from "../components/MaterialIconTextButtonsFooter";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import { Center } from "@builderx/utils";
import EntypoIcon from "react-native-vector-icons/Entypo";
import MaterialIconsIcon from "react-native-vector-icons/MaterialIcons";

function HomeScreenHost(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <MaterialIconTextButtonsFooter
        style={styles.materialIconTextButtonsFooter1}
      ></MaterialIconTextButtonsFooter>
      <View style={styles.contain}>
        <View style={styles.center_container}>
          <View style={styles.left_grp}>
            <View style={styles.grp1}>
              <View style={styles.grp1_shadding}></View>
              <TouchableOpacity style={styles.grp1_btn}>
                <View style={styles.rect6}>
                  <MaterialCommunityIconsIcon
                    name="qrcode-scan"
                    style={styles.icon}
                  ></MaterialCommunityIconsIcon>
                  <Text style={styles.scanQrCode}>Scan QR Code</Text>
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.grp3}>
              <View style={styles.grp3_shadding}></View>
              <Center>
                <TouchableOpacity style={styles.grp3_btn}>
                  <View style={styles.rect9}>
                    <EntypoIcon name="list" style={styles.icon3}></EntypoIcon>
                    <Text style={styles.viewList}>View List</Text>
                  </View>
                </TouchableOpacity>
              </Center>
            </View>
          </View>
          <View style={styles.right_grp}>
            <View style={styles.grp2}>
              <View style={styles.grp2_shadding}></View>
              <Center>
                <TouchableOpacity style={styles.grp2_btn}>
                  <View style={styles.rect8}>
                    <MaterialCommunityIconsIcon
                      name="qrcode-edit"
                      style={styles.icon2}
                    ></MaterialCommunityIconsIcon>
                    <Text style={styles.generateQrCode}>Generate QR Code</Text>
                  </View>
                </TouchableOpacity>
              </Center>
            </View>
            <View style={styles.grp4}>
              <View style={styles.grp4_shadding}></View>
              <Center>
                <TouchableOpacity style={styles.grp4_btn}>
                  <View style={styles.rect10}>
                    <MaterialIconsIcon
                      name="add-to-photos"
                      style={styles.icon4}
                    ></MaterialIconsIcon>
                    <Text style={styles.addLecture}>Add Lecture</Text>
                  </View>
                </TouchableOpacity>
              </Center>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  materialIconTextButtonsFooter1: {
    height: 56,
    width: 360,
    backgroundColor: "rgba(255,255,255,1)",
    marginTop: 684
  },
  contain: {
    height: 381,
    flexDirection: "row",
    justifyContent: "center",
    marginTop: -680
  },
  center_container: {
    width: 334,
    height: 351,
    flexDirection: "row",
    alignSelf: "center"
  },
  left_grp: {
    flex: 0.5,
    backgroundColor: "rgba(247, 247, 247,1)"
  },
  grp1: {
    flex: 0.5,
    backgroundColor: "rgba(255,255,255,1)"
  },
  grp1_shadding: {
    flex: 1,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    overflow: "hidden",
    backgroundColor: "rgba(230,230,230,1)"
  },
  grp1_btn: {
    top: 13,
    left: 8,
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect6: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid"
  },
  icon: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    marginTop: 42,
    marginLeft: 45
  },
  scanQrCode: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 16,
    marginLeft: 48
  },
  grp3: {
    flex: 0.5
  },
  grp3_shadding: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  grp3_btn: {
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect9: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid",
    marginTop: 2
  },
  icon3: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    marginTop: 40,
    marginLeft: 45
  },
  viewList: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 16,
    marginLeft: 77
  },
  right_grp: {
    flex: 0.5,
    backgroundColor: "rgba(210, 210, 210,1)"
  },
  grp2: {
    flex: 0.5,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  grp2_shadding: {
    flex: 1,
    backgroundColor: "rgba(230,230,230,1)"
  },
  grp2_btn: {
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect8: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid"
  },
  icon2: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    marginTop: 42,
    marginLeft: 45
  },
  generateQrCode: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 16,
    marginLeft: 22
  },
  grp4: {
    flex: 0.5
  },
  grp4_shadding: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  grp4_btn: {
    width: 150,
    height: 150,
    position: "absolute"
  },
  rect10: {
    width: 150,
    height: 150,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 15,
    shadowColor: "rgba(255,255,255,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,1)",
    borderStyle: "solid"
  },
  icon4: {
    color: "rgba(0,0,0,1)",
    fontSize: 60,
    height: 60,
    width: 60,
    marginTop: 45,
    marginLeft: 45
  },
  addLecture: {
    fontFamily: "roboto-700",
    color: "#121212",
    marginTop: 19,
    marginLeft: 62
  }
});

export default HomeScreenHost;
