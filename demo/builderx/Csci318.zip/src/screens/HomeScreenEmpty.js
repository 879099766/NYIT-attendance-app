import React, { Component } from "react";
import { StyleSheet, View, StatusBar, TouchableOpacity } from "react-native";
import MaterialIconTextButtonsFooter from "../components/MaterialIconTextButtonsFooter";

function HomeScreenEmpty(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <MaterialIconTextButtonsFooter
        style={styles.materialIconTextButtonsFooter1}
      ></MaterialIconTextButtonsFooter>
      <View style={styles.group}>
        <View style={styles.group2}>
          <View style={styles.rect}>
            <TouchableOpacity style={styles.button}></TouchableOpacity>
            <View style={styles.rect4}></View>
          </View>
          <View style={styles.rect2}>
            <View style={styles.rect5}></View>
            <View style={styles.rect6}></View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  materialIconTextButtonsFooter1: {
    height: 56,
    backgroundColor: "rgba(255,255,255,1)",
    marginTop: 684
  },
  group: {
    height: 381,
    flexDirection: "row",
    justifyContent: "center",
    marginTop: -680
  },
  group2: {
    width: 334,
    height: 351,
    flexDirection: "row",
    alignSelf: "center"
  },
  rect: {
    flex: 0.5,
    backgroundColor: "rgba(247, 247, 247,1)"
  },
  button: {
    flex: 0.5,
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    overflow: "hidden"
  },
  rect4: {
    flex: 0.5,
    backgroundColor: "rgba(212, 212, 212,1)"
  },
  rect2: {
    flex: 0.5,
    backgroundColor: "rgba(210, 210, 210,1)"
  },
  rect5: {
    flex: 0.5,
    backgroundColor: "rgba(220, 220, 220,1)"
  },
  rect6: {
    flex: 0.5,
    backgroundColor: "rgba(248, 248, 248,1)"
  }
});

export default HomeScreenEmpty;
