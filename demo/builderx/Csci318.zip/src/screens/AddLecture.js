import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  Text,
  TextInput,
  Switch,
  TouchableOpacity
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";

function AddLecture(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group}>
        <View style={styles.rect}>
          <View style={styles.iconRow}>
            <Icon name="ios-arrow-back" style={styles.icon}></Icon>
            <Text style={styles.text}>Add Lecture</Text>
          </View>
        </View>
      </View>
      <View style={styles.group2}>
        <View style={styles.background_1}>
          <View style={styles.input_shadding1}>
            <TextInput
              placeholder="   Course Title"
              clearButtonMode="while-editing"
              autoCapitalize="sentences"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              style={styles.input1}
            ></TextInput>
          </View>
          <View style={styles.input_shadding2}>
            <TextInput
              placeholder="   Max Students"
              clearButtonMode="while-editing"
              autoCapitalize="sentences"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              keyboardType="number-pad"
              style={styles.input2}
            ></TextInput>
          </View>
        </View>
      </View>
      <View style={styles.group3}>
        <View style={styles.background_2}>
          <View style={styles.input_shadding3}>
            <TextInput
              placeholder="   Date"
              clearButtonMode="while-editing"
              autoCapitalize="none"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              dataDetector="calendarEvent"
              style={styles.input3}
            ></TextInput>
          </View>
          <View style={styles.input_shadding4}>
            <TextInput
              placeholder="   Time"
              clearButtonMode="while-editing"
              autoCapitalize="sentences"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              keyboardType="number-pad"
              dataDetector="calendarEvent"
              style={styles.input4}
            ></TextInput>
          </View>
          <View style={styles.switchRow}>
            <Switch value={true} style={styles.switch}></Switch>
            <Text style={styles.addAdditionTime}>Add Addition Time</Text>
          </View>
          <View style={styles.input_shadding5}>
            <TextInput
              placeholder="   Date"
              clearButtonMode="while-editing"
              autoCapitalize="none"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              dataDetector="calendarEvent"
              style={styles.input5}
            ></TextInput>
          </View>
          <View style={styles.input_shadding6}>
            <TextInput
              placeholder="   Time"
              clearButtonMode="while-editing"
              autoCapitalize="sentences"
              clearTextOnFocus={true}
              spellCheck={true}
              autoCorrect={true}
              keyboardType="number-pad"
              dataDetector="calendarEvent"
              style={styles.input6}
            ></TextInput>
          </View>
          <TouchableOpacity style={styles.btn_submit}>
            <Text style={styles.btn_txt_submit}>Submit</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230,230,230,1)"
  },
  group: {
    height: 60
  },
  rect: {
    height: 60,
    backgroundColor: "rgba(8,8,8,1)",
    flexDirection: "row"
  },
  icon: {
    color: "rgba(255,255,255,1)",
    fontSize: 32,
    height: 35,
    width: 12
  },
  text: {
    fontFamily: "roboto-700",
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 19,
    marginTop: 7
  },
  iconRow: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 211,
    marginLeft: 20,
    marginTop: 12
  },
  group2: {
    height: 171,
    marginTop: 25
  },
  background_1: {
    height: 170,
    backgroundColor: "rgba(255,255,255,1)"
  },
  input_shadding1: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 26,
    marginLeft: 15
  },
  input1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  input_shadding2: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 25,
    marginLeft: 15
  },
  input2: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  group3: {
    height: 372,
    marginTop: 27
  },
  background_2: {
    height: 372,
    backgroundColor: "rgba(255,255,255,1)"
  },
  input_shadding3: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 26,
    marginLeft: 15
  },
  input3: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  input_shadding4: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 25,
    marginLeft: 15
  },
  input4: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  switch: {},
  addAdditionTime: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 15,
    marginLeft: 12,
    marginTop: 2
  },
  switchRow: {
    height: 20,
    flexDirection: "row",
    marginTop: 18,
    marginLeft: 16,
    marginRight: 168
  },
  input_shadding5: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 16,
    marginLeft: 15
  },
  input5: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  input_shadding6: {
    width: 330,
    height: 45,
    backgroundColor: "rgba(181,181,181,1)",
    marginTop: 22,
    marginLeft: 15
  },
  input6: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 45,
    width: 330
  },
  btn_submit: {
    width: 328,
    height: 33,
    backgroundColor: "rgba(7,161,80,1)",
    shadowColor: "rgba(0,0,0,1)",
    shadowOffset: {
      width: 3,
      height: 3
    },
    elevation: 5,
    shadowOpacity: 0.01,
    shadowRadius: 0,
    borderWidth: 1,
    borderColor: "rgba(252,252,252,1)",
    overflow: "hidden",
    marginTop: 18,
    marginLeft: 16
  },
  btn_txt_submit: {
    fontFamily: "roboto-regular",
    color: "rgba(255,252,252,1)",
    marginTop: 8,
    marginLeft: 142
  }
});

export default AddLecture;
