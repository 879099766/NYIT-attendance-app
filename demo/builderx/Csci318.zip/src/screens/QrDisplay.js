import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";
import IoniconsIcon from "react-native-vector-icons/Ionicons";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";

function QrDisplay(props) {
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <View style={styles.group1}>
        <View style={styles.rect1}>
          <View style={styles.icon1Row}>
            <IoniconsIcon
              name="ios-arrow-back"
              style={styles.icon1}
            ></IoniconsIcon>
            <Text style={styles.csci318Qr}>CSCI 318 - QR</Text>
          </View>
        </View>
      </View>
      <View style={styles.group2}>
        <View style={styles.group3}>
          <View style={styles.rect2}>
            <FontAwesomeIcon
              name="qrcode"
              style={styles.icon2}
            ></FontAwesomeIcon>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(230, 230, 230,1)"
  },
  group1: {
    width: 360,
    height: 60
  },
  rect1: {
    height: 60,
    backgroundColor: "rgba(8,8,8,1)",
    flexDirection: "row"
  },
  icon1: {
    color: "rgba(255,255,255,1)",
    fontSize: 32,
    height: 35,
    width: 12
  },
  csci318Qr: {
    fontFamily: "roboto-700",
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 19,
    marginTop: 7
  },
  icon1Row: {
    height: 35,
    flexDirection: "row",
    flex: 1,
    marginRight: 193,
    marginLeft: 20,
    marginTop: 12
  },
  group2: {
    height: 349,
    backgroundColor: "rgba(253,253,253,1)",
    marginTop: 65
  },
  group3: {
    width: 314,
    height: 292,
    marginTop: 28,
    marginLeft: 23
  },
  rect2: {
    width: 314,
    height: 292,
    backgroundColor: "rgba(255,255,255,1)",
    borderWidth: 1,
    borderColor: "#000000"
  },
  icon2: {
    color: "rgba(128,128,128,1)",
    fontSize: 200,
    height: 200,
    width: 157,
    marginTop: 46,
    marginLeft: 78
  }
});

export default QrDisplay;
