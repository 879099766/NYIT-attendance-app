import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import { AppLoading } from "expo";
import * as Font from "expo-font";
import AccScreen from "./src/screens/AccScreen";
import AddLecture from "./src/screens/AddLecture";
import AttendanceList from "./src/screens/AttendanceList";
import CheckIn from "./src/screens/CheckIn";
import HomeScreenEmpty from "./src/screens/HomeScreenEmpty";
import HomeScreenHost from "./src/screens/HomeScreenHost";
import HomeScreenStud from "./src/screens/HomeScreenStud";
import QrDisplay from "./src/screens/QrDisplay";
import Untitled from "./src/screens/Untitled";
import Warning from "./src/screens/Warning";

const DrawerNavigation = createDrawerNavigator({
  AccScreen: AccScreen,
  AddLecture: AddLecture,
  AttendanceList: AttendanceList,
  CheckIn: CheckIn,
  HomeScreenEmpty: HomeScreenEmpty,
  HomeScreenHost: HomeScreenHost,
  HomeScreenStud: HomeScreenStud,
  QrDisplay: QrDisplay,
  Untitled: Untitled,
  Warning: Warning
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    AccScreen: AccScreen,
    AddLecture: AddLecture,
    AttendanceList: AttendanceList,
    CheckIn: CheckIn,
    HomeScreenEmpty: HomeScreenEmpty,
    HomeScreenHost: HomeScreenHost,
    HomeScreenStud: HomeScreenStud,
    QrDisplay: QrDisplay,
    Untitled: Untitled,
    Warning: Warning
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "roboto-700": require("./src/assets/fonts/roboto-700.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
